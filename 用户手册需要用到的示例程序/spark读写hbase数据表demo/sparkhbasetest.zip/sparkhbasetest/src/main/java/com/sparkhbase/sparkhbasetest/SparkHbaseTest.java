package com.sparkhbase.sparkhbasetest;
 
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableInputFormat;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.rdd.RDD;
import org.apache.spark.sql.SparkSession;
import scala.Function1;
import scala.Tuple2;
import scala.collection.Iterator;
import scala.runtime.BoxedUnit;
 
/***
 * 使用Spark 直接查询 Hbase 数据。
 * */
public class SparkHbaseTest {
    public static void main(String[] args) {
        Configuration confhbase = HBaseConfiguration.create();
 
        confhbase.set("hbase.zookeeper.property.clientPort", "2181");
        confhbase.set("hbase.zookeeper.quorum", "172.16.32.13,172.16.32.17,172.16.32.28");
 
        String tablename = "mk_bulkload_text";
        confhbase.set(TableInputFormat.INPUT_TABLE, tablename);
        SparkConf conf = new SparkConf().setAppName("Spark_Hbase_Test").setMaster("yarn");
        JavaSparkContext sc = new JavaSparkContext(conf);
        JavaPairRDD<ImmutableBytesWritable, Result> resultRDD = sc.newAPIHadoopRDD(confhbase, TableInputFormat.class, ImmutableBytesWritable.class, Result.class);
 
        long count = resultRDD.count();
        System.out.print("************SPARK from hbase  count ***************      " + count + "   rows         ");
 
        resultRDD.foreach(new VoidFunction<Tuple2<ImmutableBytesWritable, Result>>() {
            public void call(Tuple2<ImmutableBytesWritable, Result> v1) throws Exception {
                String rowkey = Bytes.toString(v1._2().getRow());
                String col_a = Bytes.toString(v1._2().getValue(Bytes.toBytes("cf"), Bytes.toBytes("a")));
                String col_b = Bytes.toString(v1._2().getValue(Bytes.toBytes("cf"), Bytes.toBytes("b")));
                System.out.print("==spark from hbase  record=== ：  " + rowkey + "  " + col_a);
                System.out.print("==spark from hbase  record=== ：  " + rowkey + "  " + col_b);
            }
        });
    }
}