#!/bin/bash
export HADOOP_USER_NAME=hdfs
hadoop jar tbdsDemo-0.0.1-SNAPSHOT.jar  com.tencent.export.ExportDataFromTimeSeriesDB -conf ./ctsdb.properties


